#pragma once

class MissionNotFound {};

class DriverNotFound {};

class DuplicateDriverMission {};

class DuplicateMissionID {};

class DriverMissionNotFound {};