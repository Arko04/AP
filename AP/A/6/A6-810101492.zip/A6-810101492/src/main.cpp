#include "input_handler.hpp"

int main()
{
    InputHandler system;
    system.handle_input();
}
