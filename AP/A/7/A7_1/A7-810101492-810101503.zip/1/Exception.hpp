class BadRequest
{};

class NotFound
{};

class Empty
{};

class PermissionDenied
{};

class PlayerNotAvailable
{};